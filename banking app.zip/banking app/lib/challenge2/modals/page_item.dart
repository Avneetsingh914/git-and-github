
class PageItem{

  String thumbnail;
  String title;

  PageItem({this.thumbnail="", this.title=""});

}