
class User{
  String _name,_profilePic;

  User(this._name, this._profilePic);

  String get name => _name;

  get profilePic => _profilePic;

}