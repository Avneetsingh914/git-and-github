class Balance {
  final String time;
  final double money;

  Balance(this.time, this.money);
}
