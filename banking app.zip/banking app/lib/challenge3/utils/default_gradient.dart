import 'package:flutter/material.dart';

class DefaultGradient {
  static const defaultGradient = LinearGradient(
    colors: [Color(0xfff85032), Color(0xffe73827)],
  );
}
