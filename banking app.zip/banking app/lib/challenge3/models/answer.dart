
enum AnswerType{
  Wrong,
  Right,
  NotSelected
}