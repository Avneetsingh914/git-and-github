# payment

Flutter payment app ui.-[Dribble Challenge](https://dribbble.com/shots/6104857-Online-Banking-App)

## Screenshots
![s1.png](https://www.dropbox.com/s/uqzqrw7bm38d0on/s1.png?dl=0&raw=1)![s2.png](https://www.dropbox.com/s/46ifalal147l63q/s2.png?dl=0&raw=1) 

### If you like this repository then show some ♥ by giving stars on repo.

## Author
[Bhavneet Singh](https://github.com/singhbhavneet/)
